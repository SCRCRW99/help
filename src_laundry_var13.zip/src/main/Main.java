package main;

import logic.LaundryQueue;
import models.BulkyLaundry;
import models.LaundryRequest;
import models.RegularLaundry;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Начальный номер N вводится один раз строго по заданию
        int n = 0;
        while (true) {
            System.out.print("Введите начальный номер N (от 1 до 36): ");
            try {
                String input = scanner.nextLine().trim();
                n = Integer.parseInt(input);
                if (n >= 1 && n <= 36) {
                    break;
                }
                System.out.println("Ошибка: номер должен быть в диапазоне от 1 до 36.");
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите целое число.");
            }
        }

        // Начальная вместимость 10 единиц строго по заданию
        LaundryQueue<LaundryRequest> queue = new LaundryQueue<>(10);

        boolean stage1Completed = false;
        boolean running = true;

        while (running) {
            System.out.println("\n=== СИСТЕМА ПРАЧЕЧНОЙ САМООБСЛУЖИВАНИЯ (N = " + n + ") ===");
            System.out.println("1. Выполнить задание 1 и вывести назначенный вариант задания 2");
            System.out.println("4. Показать очередь, статусы и вместимость машины");
            System.out.println("5. Выход из программы");
            System.out.print("Выберите пункт (1, 4, 5): ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    if (stage1Completed) {
                        System.out.println("Задание 1 уже было выполнено ранее!");
                        break;
                    }
                    try {
                        int nextStageB = executeStage1(queue, n);
                        stage1Completed = true;
                        System.out.println("Задание 1 успешно выполнено!");
                        System.out.println("Назначенный вариант задания 2: Б" + nextStageB);
                    } catch (Exception e) {
                        System.out.println("Ошибка при выполнении задания 1: " + e.getMessage());
                    }
                    break;

                case "4":
                    handleShowQueue(queue);
                    break;

                case "5":
                    System.out.println("Выход из программы.");
                    running = false;
                    break;

                default:
                    System.out.println("Неверный пункт меню. Повторите ввод.");
                    break;
            }
        }
    }

    private static int executeStage1(LaundryQueue<LaundryRequest> queue, int n) {
        // Исходные данные строго по заданию:
        // RegularLaundry: (301, 31, 3, 2, 5); (303, 32, 4, 2, 5); (305, 33, 2, 2, 2); (308, 34, 6, 2, 3); (310, 35, 11, 1, 5).
        // BulkyLaundry: (302, 31, 4, 1, 4, 1); (304, 32, 2, 1, 3, 2); (306, 33, 5, 1, 4, 2); (307, 34, 1, 1, 1, 1); (309, 32, 1, 1, 4, 1).
        List<LaundryRequest> initialData = Arrays.asList(
                new RegularLaundry(301, 31, 3, 2, 5),
                new RegularLaundry(303, 32, 4, 2, 5),
                new RegularLaundry(305, 33, 2, 2, 2),
                new RegularLaundry(308, 34, 6, 2, 3),
                new RegularLaundry(310, 35, 11, 1, 5),
                new BulkyLaundry(302, 31, 4, 1, 4, 1),
                new BulkyLaundry(304, 32, 2, 1, 3, 2),
                new BulkyLaundry(306, 33, 5, 1, 4, 2),
                new BulkyLaundry(307, 34, 1, 1, 1, 1),
                new BulkyLaundry(309, 32, 1, 1, 4, 1)
        );

        // Таблица 1. Вариант 13 (условие А3):
        // "А3. Малая загрузка. Загрузка не более 4 единиц и priority не ниже 2."
        Predicate<LaundryRequest> filterA3 = r -> (r.getLoadUnits() <= 4) && (r.getPriority() >= 2);

        List<LaundryRequest> selected = initialData.stream()
                .filter(filterA3)
                .sorted(Comparator.comparingInt(LaundryRequest::getId))
                .collect(Collectors.toList());

        List<Integer> ids = new ArrayList<>();
        int totalLoad = 0;

        for (LaundryRequest req : selected) {
            queue.add(req);
            ids.add(req.getId());
            totalLoad += req.getLoadUnits();
        }

        // Вывод результатов этапа 1 по заданию
        System.out.println("Выбранные заявки (ID по возрастанию): " + ids);
        System.out.println("Суммарная загрузка: " + totalLoad + " ед.");

        // Проверка через готовый служебный класс StageAccess с переданным n
        return StageAccess.second(n, ids, totalLoad);
    }

    private static void handleShowQueue(LaundryQueue<LaundryRequest> queue) {
        System.out.println("\n--- Состояние очереди заявок ---");
        System.out.println("Вместимость машины: " + queue.getCapacity() + " ед.");

        List<LaundryRequest> all = queue.getAnalyticsStream().collect(Collectors.toList());
        if (all.isEmpty()) {
            System.out.println("Очередь пуста (сначала выполните пункт 1 для добавления отобранных заявок).");
        } else {
            System.out.println("Список заявок в очереди:");
            for (LaundryRequest r : all) {
                System.out.println(r.getDetails());
            }
        }
    }
}

// Готовый служебный класс из файла Java_Retake_New_v3_CopyCode.txt
final class StageAccess {
    private static final int[] S = {2, 5, 4, 0, 1, 3};
    private static final int[] A = {
        0xec9a9bee, 0xe4008178, 0x90362d55, 0xfd76dc38, 0x26474398,
        0x09b07677
    };
    private static final int[] B = {
        0x3d997b45, 0x304e1445, 0xe673e62a, 0x3d997b45, 0x3d997b45,
        0xe30a38ad, 0x3d997b45, 0xb2d7f90f, 0x3d997b45, 0x3d997b45,
        0x3d997b45, 0xac048f11, 0xf9259ef1, 0xe673e62a, 0x5fcb48b5,
        0x5fcb48b5, 0xe673e62a, 0x5fcb48b5, 0xbe382650, 0x3d997b45,
        0x3d997b45, 0xdadf3629, 0x3d997b45, 0x304e1445, 0xe673e62a,
        0x5fcb48b5, 0x5fcb48b5, 0xe30a38ad, 0x5fcb48b5, 0x304e1445,
        0x41032501, 0x41032501, 0xe30a38ad, 0x41032501, 0xd4330e26,
        0xe673e62a
    };
    static int initial(int n) {
        if (n < 1 || n > 36)
            throw new IllegalArgumentException("N: 1..36");
        return (n - 1) / 6 + 1;
    }
    static int second(int n, java.util.List<Integer> ids, int load) {
        return check(n, ids, load, 0, A[initial(n) - 1], 0);
    }
    static int third(int n, java.util.List<Integer> ids,
                     int load, int mode) {
        int a = initial(n);
        int b = 1 + Math.floorMod((long) A[a - 1] + (n - 1) % 6, 6);
        return check(n, ids, load, mode, B[n - 1], b);
    }
    private static int check(int n, java.util.List<Integer> ids,
            int load, int mode, int expected, int previous) {
        if (ids == null) throw new IllegalArgumentException("ids: null");
        int actual = (ids + "|" + load + "|" + mode).hashCode();
        if (actual != expected)
            throw new IllegalStateException("Check stage result");
        int p = (n - 1) % 6;
        long key = previous == 0 ? (long) actual + p
            : ((actual >>> 31) ^ (actual >>> 2)) + 1L * p 
              + 0L * previous + S[initial(n) - 1];
        return 1 + Math.floorMod(key, 6);
    }
}
