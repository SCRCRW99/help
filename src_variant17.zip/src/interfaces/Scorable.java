package interfaces;

/**
 * Общий интерфейс для всего, что имеет конкурсный балл.
 */
public interface Scorable {

    /**
     * @return конкурсный балл объекта
     */
    double calculateScore();
}
