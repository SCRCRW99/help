package main;

import logic.ScholarshipManager;
import models.AcademicApplication;
import models.ResearchApplication;
import models.ScholarshipApplication;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

/**
 * Консольный интерфейс системы распределения стипендий (вариант 17).
 */
public class Main {

    private static final String STATE_FILE = "scholarship_state.dat";
    private static final Scanner SCANNER = new Scanner(System.in);

    public static void main(String[] args) {
        ScholarshipManager<ScholarshipApplication> manager = new ScholarshipManager<>();
        loadState(manager);

        boolean running = true;
        while (running) {
            System.out.println();
            System.out.println("=== Система распределения стипендий ===");
            System.out.println("1. Добавить заявку");
            System.out.println("2. Показать все заявки");
            System.out.println("3. Провести конкурс");
            System.out.println("4. Аналитический запрос (вариант 17)");
            System.out.println("5. Выход");

            int choice = readInt("Выберите пункт меню: ");
            switch (choice) {
                case 1:
                    addApplication(manager);
                    break;
                case 2:
                    showAll(manager);
                    break;
                case 3:
                    runContest(manager);
                    break;
                case 4:
                    runAnalytics(manager);
                    break;
                case 5:
                    // При ошибке сохранения — сообщение и возврат в меню.
                    if (saveState(manager)) {
                        running = false;
                    }
                    break;
                default:
                    System.out.println("Нет такого пункта меню, попробуйте снова.");
            }
        }
    }

    private static void addApplication(ScholarshipManager<ScholarshipApplication> manager) {
        int type = readInt("Тип заявки (1 — учебная, 2 — научная): ");
        if (type != 1 && type != 2) {
            System.out.println("Ошибка: тип заявки должен быть 1 или 2.");
            return;
        }

        int id = readInt("ID заявки: ");
        int studentId = readInt("ID студента: ");

        try {
            ScholarshipApplication application;
            if (type == 1) {
                int exam1 = readInt("Оценка exam1 (0..100): ");
                int exam2 = readInt("Оценка exam2 (0..100): ");
                application = new AcademicApplication(id, studentId, exam1, exam2);
            } else {
                int articles = readInt("Число статей (0..5): ");
                int talks = readInt("Число докладов (0..10): ");
                application = new ResearchApplication(id, studentId, articles, talks);
            }
            if (manager.add(application)) {
                System.out.println("Заявка добавлена.");
            } else {
                System.out.println("Заявка не добавлена: пустая заявка или ID уже занят.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    private static void showAll(ScholarshipManager<ScholarshipApplication> manager) {
        List<ScholarshipApplication> applications =
                manager.getAnalyticsStream().collect(Collectors.toList());
        if (applications.isEmpty()) {
            System.out.println("Заявок пока нет.");
            return;
        }
        System.out.println("Все заявки:");
        for (ScholarshipApplication application : applications) {
            System.out.println("  " + application.getDetails());
        }
    }

    private static void runContest(ScholarshipManager<ScholarshipApplication> manager) {
        int limit = readInt("Введите число стипендий (limit): ");
        try {
            List<ScholarshipApplication> winners = manager.allocate(limit);
            if (winners.isEmpty()) {
                System.out.println("Победителей нет.");
                return;
            }
            System.out.println("Победители конкурса (в порядке рейтинга):");
            for (ScholarshipApplication winner : winners) {
                double rating = manager.getStudentRating(winner.getStudentId()).orElse(0.0);
                System.out.printf("  studentId=%d, конкурсный рейтинг=%.2f, id заявки=%d%n",
                        winner.getStudentId(), rating, winner.getId());
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    /**
     * Вариант 17, аналитика: ID трёх студентов с наибольшим личным максимумом
     * среди студентов, имеющих заявку с баллом не ниже 60.
     * При равенстве — меньший studentId. Только Stream API, без циклов.
     */
    private static void runAnalytics(ScholarshipManager<ScholarshipApplication> manager) {
        List<Map.Entry<Integer, Double>> top = manager.getAnalyticsStream()
                .collect(Collectors.groupingBy(ScholarshipApplication::getStudentId))
                .entrySet().stream()
                .map(entry -> new AbstractMap.SimpleEntry<>(
                        entry.getKey(),
                        entry.getValue().stream()
                                .mapToDouble(ScholarshipApplication::calculateScore)
                                .max()
                                .orElse(0.0)))
                .filter(entry -> entry.getValue() >= 60)
                .sorted(Comparator
                        .<Map.Entry<Integer, Double>>comparingDouble(Map.Entry::getValue).reversed()
                        .thenComparingInt(Map.Entry::getKey))
                .limit(3)
                .collect(Collectors.toList());

        if (top.isEmpty()) {
            System.out.println("Нет студентов с заявкой с баллом не ниже 60.");
            return;
        }
        System.out.println("ID трёх студентов с наибольшим личным максимумом:");
        top.forEach(entry -> System.out.printf("  studentId=%d (личный максимум %.2f)%n",
                entry.getKey(), entry.getValue()));
    }

    /** Начальные данные в указанном порядке. */
    private static void createInitialData(ScholarshipManager<ScholarshipApplication> manager) {
        manager.add(new AcademicApplication(1, 1, 100, 100));
        manager.add(new AcademicApplication(3, 2, 85, 85));
        manager.add(new AcademicApplication(4, 2, 85, 85));
        manager.add(new AcademicApplication(5, 3, 80, 80));
        manager.add(new AcademicApplication(7, 4, 60, 60));
        manager.add(new AcademicApplication(9, 5, 59, 59));
        manager.add(new AcademicApplication(11, 6, 90, 90));
        manager.add(new AcademicApplication(13, 7, 100, 100));

        manager.add(new ResearchApplication(2, 1, 3, 0));
        manager.add(new ResearchApplication(6, 3, 4, 0));
        manager.add(new ResearchApplication(8, 4, 3, 0));
        manager.add(new ResearchApplication(10, 5, 5, 0));
        manager.add(new ResearchApplication(12, 6, 4, 1));
    }

    /** Загрузка состояния при старте; при проблемах — начальные данные. */
    @SuppressWarnings("unchecked")
    private static void loadState(ScholarshipManager<ScholarshipApplication> manager) {
        java.io.File file = new java.io.File(STATE_FILE);
        if (!file.exists()) {
            createInitialData(manager);
            return;
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            List<ScholarshipApplication> applications = (List<ScholarshipApplication>) in.readObject();
            for (ScholarshipApplication application : applications) {
                manager.add(application);
            }
            System.out.println("Состояние загружено из " + STATE_FILE);
        } catch (Exception e) {
            System.out.println("Не удалось прочитать файл состояния ("
                    + e.getMessage() + "). Используются начальные данные.");
            createInitialData(manager);
        }
    }

    /**
     * Сохранение состояния при выходе. Возвращает true, если сохранение удалось.
     * Сообщение об успешном сохранении не выводится (по условию задачи).
     */
    private static boolean saveState(ScholarshipManager<ScholarshipApplication> manager) {
        List<ScholarshipApplication> applications =
                manager.getAnalyticsStream().collect(Collectors.toList());
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(STATE_FILE))) {
            out.writeObject(new ArrayList<>(applications));
            return true;
        } catch (IOException e) {
            System.out.println("Ошибка сохранения состояния: " + e.getMessage());
            return false;
        }
    }

    /** Безопасное чтение целого числа: некорректный ввод не завершает программу. */
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = SCANNER.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите целое число.");
            }
        }
    }
}
