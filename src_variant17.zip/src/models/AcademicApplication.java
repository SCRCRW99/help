package models;

/**
 * Учебная заявка: две экзаменационные оценки.
 * Балл — среднее арифметическое exam1 и exam2.
 */
public class AcademicApplication extends ScholarshipApplication {

    private static final long serialVersionUID = 1L;

    private final int exam1;
    private final int exam2;

    public AcademicApplication(int id, int studentId, int exam1, int exam2) {
        super(id, studentId);
        if (exam1 < 0 || exam1 > 100) {
            throw new IllegalArgumentException("Оценка exam1 должна быть от 0 до 100");
        }
        if (exam2 < 0 || exam2 > 100) {
            throw new IllegalArgumentException("Оценка exam2 должна быть от 0 до 100");
        }
        this.exam1 = exam1;
        this.exam2 = exam2;
    }

    public int getExam1() {
        return exam1;
    }

    public int getExam2() {
        return exam2;
    }

    @Override
    public double calculateScore() {
        return (exam1 + exam2) / 2.0;
    }
}
