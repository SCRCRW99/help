package models;

import interfaces.Scorable;

import java.io.Serializable;

/**
 * Абстрактная заявка на стипендию.
 */
public abstract class ScholarshipApplication implements Scorable, Serializable {

    private static final long serialVersionUID = 1L;

    private final int id;
    private final int studentId;
    private boolean awarded;

    protected ScholarshipApplication(int id, int studentId) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID заявки должен быть положительным числом");
        }
        if (studentId <= 0) {
            throw new IllegalArgumentException("ID студента должен быть положительным числом");
        }
        this.id = id;
        this.studentId = studentId;
        this.awarded = false;
    }

    public int getId() {
        return id;
    }

    public int getStudentId() {
        return studentId;
    }

    public boolean isAwarded() {
        return awarded;
    }

    public void setAwarded(boolean awarded) {
        this.awarded = awarded;
    }

    /**
     * Сведения о заявке: тип, идентификаторы, балл и результат назначения.
     */
    public String getDetails() {
        return String.format("%s: id=%d, студент=%d, балл=%.2f, назначена=%s",
                getClass().getSimpleName(),
                id,
                studentId,
                calculateScore(),
                awarded ? "да" : "нет");
    }
}
