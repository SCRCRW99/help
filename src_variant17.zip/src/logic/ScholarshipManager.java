package logic;

import models.ScholarshipApplication;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Менеджер заявок с конкурсной логикой варианта 17 «Подтверждённое достижение».
 *
 * Правило конкурса: допускается студент не менее чем с двумя заявками с баллом
 * не ниже 80 (типы могут совпадать). Рейтинг — среднее двух наибольших баллов
 * его заявок.
 */
public class ScholarshipManager<T extends ScholarshipApplication> {

    /** Минимальный балл заявки, учитываемой правилом допуска (вариант 17). */
    private static final double MIN_HIGH_SCORE = 80.0;

    /** Число заявок с высоким баллом, необходимых для допуска. */
    private static final long MIN_HIGH_SCORE_COUNT = 2;

    private final List<T> applications = new ArrayList<>();

    /** Условие допуска студента к конкурсу (вариант 17). */
    private final Predicate<List<T>> admissionRule =
            apps -> apps.stream()
                    .map(ScholarshipApplication::calculateScore)
                    .filter(score -> score >= MIN_HIGH_SCORE)
                    .count() >= MIN_HIGH_SCORE_COUNT;

    /**
     * Добавляет заявку. При null или повторном id возвращает false без изменения
     * данных. При успехе сбрасывает предыдущие результаты назначения.
     */
    public boolean add(T application) {
        if (application == null) {
            return false;
        }
        for (T existing : applications) {
            if (existing.getId() == application.getId()) {
                return false;
            }
        }
        resetAwarded();
        return applications.add(application);
    }

    /**
     * Проводит конкурс по варианту 17, обновляет awarded и возвращает
     * победившие заявки в порядке рейтинга.
     */
    public List<T> allocate(int limit) {
        if (limit < 0) {
            throw new IllegalArgumentException("Число стипендий не может быть отрицательным");
        }
        resetAwarded();
        List<T> winnersApplications = new ArrayList<>();
        if (limit == 0) {
            return winnersApplications;
        }

        Map<Integer, List<T>> byStudent = new HashMap<>();
        for (T application : applications) {
            byStudent
                    .computeIfAbsent(application.getStudentId(), key -> new ArrayList<>())
                    .add(application);
        }

        Map<Integer, Double> ratings = new HashMap<>();
        for (Map.Entry<Integer, List<T>> entry : byStudent.entrySet()) {
            if (admissionRule.test(entry.getValue())) {
                ratings.put(entry.getKey(), ratingOf(entry.getValue()));
            }
        }

        // Участники: рейтинг по убыванию, при равенстве — меньший studentId.
        Comparator<Map.Entry<Integer, Double>> participantOrder =
                Comparator.<Map.Entry<Integer, Double>>comparingDouble(Map.Entry::getValue).reversed()
                        .thenComparingInt(Map.Entry::getKey);

        List<Integer> winners = ratings.entrySet().stream()
                .sorted(participantOrder)
                .limit(limit)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // У победителя awarded = true только у заявки с наибольшим баллом,
        // при равенстве — с меньшим id.
        Comparator<T> bestApplicationOrder =
                Comparator.<T>comparingDouble(ScholarshipApplication::calculateScore).reversed()
                        .thenComparingInt(ScholarshipApplication::getId);

        for (Integer studentId : winners) {
            T best = byStudent.get(studentId).stream()
                    .min(bestApplicationOrder)
                    .orElseThrow(AssertionError::new);
            best.setAwarded(true);
            winnersApplications.add(best);
        }
        return winnersApplications;
    }

    /** Рейтинг студента — среднее двух наибольших баллов его заявок. */
    private double ratingOf(List<T> studentApplications) {
        return studentApplications.stream()
                .map(ScholarshipApplication::calculateScore)
                .sorted(Comparator.reverseOrder())
                .limit(2)
                .mapToDouble(Double::doubleValue)
                .average()
                .orElse(0.0);
    }

    private void resetAwarded() {
        for (T application : applications) {
            application.setAwarded(false);
        }
    }

    /**
     * Конкурсный рейтинг допущенного студента по текущим заявкам.
     * Для отсутствующего или недопущенного — OptionalDouble.empty().
     */
    public OptionalDouble getStudentRating(int studentId) {
        if (studentId <= 0) {
            throw new IllegalArgumentException("ID студента должен быть положительным числом");
        }
        List<T> studentApplications = applications.stream()
                .filter(application -> application.getStudentId() == studentId)
                .collect(Collectors.toList());
        if (studentApplications.isEmpty() || !admissionRule.test(studentApplications)) {
            return OptionalDouble.empty();
        }
        return OptionalDouble.of(ratingOf(studentApplications));
    }

    /** Поток заявок для аналитики. */
    public Stream<T> getAnalyticsStream() {
        return applications.stream();
    }
}
