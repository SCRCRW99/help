package models;

import interfaces.Scorable;

public abstract class ScholarshipApplication implements Scorable {
    private final int id;
    private final int studentId;
    private boolean awarded;

    public ScholarshipApplication(int id, int studentId) {
        if (id <= 0 || studentId <= 0) {
            throw new IllegalArgumentException("ID заявки и ID студента должны быть положительными числами.");
        }
        this.id = id;
        this.studentId = studentId;
        this.awarded = false;
    }

    public int getId() {
        return id;
    }

    public int getStudentId() {
        return studentId;
    }

    public boolean isAwarded() {
        return awarded;
    }

    public void setAwarded(boolean awarded) {
        this.awarded = awarded;
    }

    public String getDetails() {
        return String.format("Заявка #%d [Студент #%d]: балл = %.2f, назначена = %s",
                id, studentId, calculateScore(), awarded ? "Да" : "Нет");
    }

    @Override
    public abstract double calculateScore();
}
