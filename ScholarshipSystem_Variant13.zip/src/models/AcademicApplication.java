package models;

public class AcademicApplication extends ScholarshipApplication {
    private final int exam1;
    private final int exam2;

    public AcademicApplication(int id, int studentId, int exam1, int exam2) {
        super(id, studentId);
        if (exam1 < 0 || exam1 > 100 || exam2 < 0 || exam2 > 100) {
            throw new IllegalArgumentException("Оценки за экзамены должны быть в диапазоне от 0 до 100.");
        }
        this.exam1 = exam1;
        this.exam2 = exam2;
    }

    public int getExam1() {
        return exam1;
    }

    public int getExam2() {
        return exam2;
    }

    @Override
    public double calculateScore() {
        return (exam1 + exam2) / 2.0;
    }

    @Override
    public String getDetails() {
        return String.format("Учебная заявка #%d [Студент #%d]: экзамены (%d, %d), балл = %.2f, назначена = %s",
                getId(), getStudentId(), exam1, exam2, calculateScore(), isAwarded() ? "Да" : "Нет");
    }
}
