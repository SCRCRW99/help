package models;

public class ResearchApplication extends ScholarshipApplication {
    private final int articles;
    private final int talks;

    public ResearchApplication(int id, int studentId, int articles, int talks) {
        super(id, studentId);
        if (articles < 0 || articles > 5) {
            throw new IllegalArgumentException("Количество статей должно быть от 0 до 5.");
        }
        if (talks < 0 || talks > 10) {
            throw new IllegalArgumentException("Количество докладов должно быть от 0 до 10.");
        }
        this.articles = articles;
        this.talks = talks;
    }

    public int getArticles() {
        return articles;
    }

    public int getTalks() {
        return talks;
    }

    @Override
    public double calculateScore() {
        double score = 20.0 * articles + 10.0 * talks;
        return Math.min(score, 100.0);
    }

    @Override
    public String getDetails() {
        return String.format("Научная заявка #%d [Студент #%d]: статьи = %d, доклады = %d, балл = %.2f, назначена = %s",
                getId(), getStudentId(), articles, talks, calculateScore(), isAwarded() ? "Да" : "Нет");
    }
}
