package logic;

import models.ScholarshipApplication;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ScholarshipManager<T extends ScholarshipApplication> {
    private final List<T> applications = new ArrayList<>();

    public boolean add(T application) {
        if (application == null) {
            return false;
        }
        for (T app : applications) {
            if (app.getId() == application.getId()) {
                return false;
            }
        }
        applications.add(application);
        // При успешном добавлении сбросить предыдущие результаты назначения
        for (T app : applications) {
            app.setAwarded(false);
        }
        return true;
    }

    // Проверка допуска по Варианту 13:
    // "Допускается студент с не менее чем двумя заявками, если все баллы не ниже 40 и хотя бы один не ниже 60."
    private final Predicate<List<T>> admissionPredicate = studentApps -> {
        if (studentApps.size() < 2) {
            return false;
        }
        boolean allGte40 = studentApps.stream().allMatch(a -> a.calculateScore() >= 40.0);
        boolean anyGte60 = studentApps.stream().anyMatch(a -> a.calculateScore() >= 60.0);
        return allGte40 && anyGte60;
    };

    // Рейтинг по Варианту 13: "наибольший балл его заявок"
    private double calculateStudentRating(List<T> studentApps) {
        return studentApps.stream()
                .mapToDouble(ScholarshipApplication::calculateScore)
                .max()
                .orElse(0.0);
    }

    public OptionalDouble getStudentRating(int studentId) {
        if (studentId <= 0) {
            throw new IllegalArgumentException("ID студента должен быть положительным.");
        }
        List<T> studentApps = applications.stream()
                .filter(a -> a.getStudentId() == studentId)
                .collect(Collectors.toList());

        if (admissionPredicate.test(studentApps)) {
            return OptionalDouble.of(calculateStudentRating(studentApps));
        }
        return OptionalDouble.empty();
    }

    public static class WinnerInfo<T extends ScholarshipApplication> {
        private final int studentId;
        private final double rating;
        private final T winningApplication;

        public WinnerInfo(int studentId, double rating, T winningApplication) {
            this.studentId = studentId;
            this.rating = rating;
            this.winningApplication = winningApplication;
        }

        public int getStudentId() {
            return studentId;
        }

        public double getRating() {
            return rating;
        }

        public T getWinningApplication() {
            return winningApplication;
        }
    }

    public List<T> allocate(int limit) {
        if (limit < 0) {
            throw new IllegalArgumentException("Лимит стипендий не может быть отрицательным.");
        }

        // Сбрасываем все назначения перед конкурсом
        for (T app : applications) {
            app.setAwarded(false);
        }

        if (limit == 0 || applications.isEmpty()) {
            return Collections.emptyList();
        }

        // Группируем заявки по studentId
        Map<Integer, List<T>> byStudent = applications.stream()
                .collect(Collectors.groupingBy(ScholarshipApplication::getStudentId));

        // Отбираем допущенных студентов
        List<WinnerInfo<T>> candidates = new ArrayList<>();
        for (Map.Entry<Integer, List<T>> entry : byStudent.entrySet()) {
            int sId = entry.getKey();
            List<T> sApps = entry.getValue();
            if (admissionPredicate.test(sApps)) {
                double rating = calculateStudentRating(sApps);

                // Выбираем победную заявку:
                // "У победившего студента awarded = true только у заявки с наибольшим баллом; при равенстве с меньшим id."
                T bestApp = sApps.stream()
                        .min(Comparator.<T>comparingDouble(ScholarshipApplication::calculateScore).reversed()
                                .thenComparingInt(ScholarshipApplication::getId))
                        .orElse(null);

                if (bestApp != null) {
                    candidates.add(new WinnerInfo<>(sId, rating, bestApp));
                }
            }
        }

        // Сортируем студентов по правилу конкурса:
        // "Побеждают не более limit студентов с наибольшим рейтингом; при равенстве преимущество имеет меньший studentId."
        Comparator<WinnerInfo<T>> winnerComparator = Comparator
                .<WinnerInfo<T>>comparingDouble(WinnerInfo::getRating).reversed()
                .thenComparingInt(WinnerInfo::getStudentId);

        candidates.sort(winnerComparator);

        List<WinnerInfo<T>> winners = candidates.stream()
                .limit(limit)
                .collect(Collectors.toList());

        List<T> winningApplications = new ArrayList<>();
        for (WinnerInfo<T> w : winners) {
            w.getWinningApplication().setAwarded(true);
            winningApplications.add(w.getWinningApplication());
        }

        return winningApplications;
    }

    public Stream<T> getAnalyticsStream() {
        return applications.stream();
    }

    // Вспомогательный метод для получения информации о победителях с рейтингами для красивого вывода в меню 3
    public List<WinnerInfo<T>> getAllocateWinnersInfo(int limit) {
        if (limit < 0) {
            throw new IllegalArgumentException("Лимит стипендий не может быть отрицательным.");
        }
        allocate(limit);

        Map<Integer, List<T>> byStudent = applications.stream()
                .collect(Collectors.groupingBy(ScholarshipApplication::getStudentId));

        List<WinnerInfo<T>> winners = new ArrayList<>();
        for (Map.Entry<Integer, List<T>> entry : byStudent.entrySet()) {
            List<T> sApps = entry.getValue();
            for (T app : sApps) {
                if (app.isAwarded()) {
                    winners.add(new WinnerInfo<>(entry.getKey(), calculateStudentRating(sApps), app));
                }
            }
        }

        winners.sort(Comparator.<WinnerInfo<T>>comparingDouble(WinnerInfo::getRating).reversed()
                .thenComparingInt(WinnerInfo::getStudentId));

        return winners;
    }
}
