package main;

import logic.ScholarshipManager;
import models.AcademicApplication;
import models.ResearchApplication;
import models.ScholarshipApplication;

import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        ScholarshipManager<ScholarshipApplication> manager = new ScholarshipManager<>();

        // Инициализация начальных данных строго по заданию
        initDefaultData(manager);

        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n=== СИСТЕМА РАСПРЕДЕЛЕНИЯ СТИПЕНДИЙ (Вариант 13) ===");
            System.out.println("1. Добавить заявку");
            System.out.println("2. Показать все заявки");
            System.out.println("3. Провести конкурс");
            System.out.println("4. Выполнить аналитический запрос");
            System.out.println("5. Выход из программы");
            System.out.print("Выберите пункт меню (1-5): ");

            String input = scanner.nextLine().trim();
            switch (input) {
                case "1":
                    handleAddApplication(manager, scanner);
                    break;
                case "2":
                    handleShowApplications(manager);
                    break;
                case "3":
                    handleAllocate(manager, scanner);
                    break;
                case "4":
                    handleAnalytics(manager);
                    break;
                case "5":
                    System.out.println("Завершение работы программы.");
                    running = false;
                    break;
                default:
                    System.out.println("Ошибка: неверный пункт меню. Повторите ввод.");
                    break;
            }
        }
    }

    private static void initDefaultData(ScholarshipManager<ScholarshipApplication> manager) {
        // AcademicApplication: (1, 1, 100, 100); (3, 2, 85, 85); (4, 2, 85, 85); (5, 3, 80, 80);
        // (7, 4, 60, 60); (9, 5, 59, 59); (11, 6, 90, 90); (13, 7, 100, 100).
        // ResearchApplication: (2, 1, 3, 0); (6, 3, 4, 0); (8, 4, 3, 0); (10, 5, 5, 0); (12, 6, 4, 1).
        manager.add(new AcademicApplication(1, 1, 100, 100));
        manager.add(new ResearchApplication(2, 1, 3, 0));
        manager.add(new AcademicApplication(3, 2, 85, 85));
        manager.add(new AcademicApplication(4, 2, 85, 85));
        manager.add(new AcademicApplication(5, 3, 80, 80));
        manager.add(new ResearchApplication(6, 3, 4, 0));
        manager.add(new AcademicApplication(7, 4, 60, 60));
        manager.add(new ResearchApplication(8, 4, 3, 0));
        manager.add(new AcademicApplication(9, 5, 59, 59));
        manager.add(new ResearchApplication(10, 5, 5, 0));
        manager.add(new AcademicApplication(11, 6, 90, 90));
        manager.add(new ResearchApplication(12, 6, 4, 1));
        manager.add(new AcademicApplication(13, 7, 100, 100));
    }

    private static void handleAddApplication(ScholarshipManager<ScholarshipApplication> manager, Scanner scanner) {
        try {
            System.out.println("\n--- Добавление заявки ---");
            System.out.println("1 - Учебная (AcademicApplication)");
            System.out.println("2 - Научная (ResearchApplication)");
            System.out.print("Выберите тип заявки: ");
            String typeStr = scanner.nextLine().trim();

            if (!typeStr.equals("1") && !typeStr.equals("2")) {
                System.out.println("Ошибка: некорректный тип заявки.");
                return;
            }

            System.out.print("Введите ID заявки (положительное целое): ");
            int id = Integer.parseInt(scanner.nextLine().trim());

            System.out.print("Введите ID студента (положительное целое): ");
            int studentId = Integer.parseInt(scanner.nextLine().trim());

            ScholarshipApplication app;
            if (typeStr.equals("1")) {
                System.out.print("Введите оценку за 1-й экзамен (0-100): ");
                int exam1 = Integer.parseInt(scanner.nextLine().trim());
                System.out.print("Введите оценку за 2-й экзамен (0-100): ");
                int exam2 = Integer.parseInt(scanner.nextLine().trim());
                app = new AcademicApplication(id, studentId, exam1, exam2);
            } else {
                System.out.print("Введите количество статей (0-5): ");
                int articles = Integer.parseInt(scanner.nextLine().trim());
                System.out.print("Введите количество докладов (0-10): ");
                int talks = Integer.parseInt(scanner.nextLine().trim());
                app = new ResearchApplication(id, studentId, articles, talks);
            }

            boolean added = manager.add(app);
            if (added) {
                System.out.println("Заявка успешно добавлена!");
            } else {
                System.out.println("Ошибка: заявка с таким ID уже существует или некорректна.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Ошибка ввода: ожидалось целое число.");
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка в параметрах заявки: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Непредвиденная ошибка: " + e.getMessage());
        }
    }

    private static void handleShowApplications(ScholarshipManager<ScholarshipApplication> manager) {
        System.out.println("\n--- Список всех заявок ---");
        List<ScholarshipApplication> list = manager.getAnalyticsStream().collect(Collectors.toList());
        if (list.isEmpty()) {
            System.out.println("Заявок нет.");
            return;
        }
        for (ScholarshipApplication app : list) {
            System.out.println(app.getDetails());
        }
    }

    private static void handleAllocate(ScholarshipManager<ScholarshipApplication> manager, Scanner scanner) {
        System.out.println("\n--- Проведение конкурса ---");
        try {
            System.out.print("Введите лимит стипендий (limit >= 0): ");
            int limit = Integer.parseInt(scanner.nextLine().trim());

            List<ScholarshipManager.WinnerInfo<ScholarshipApplication>> winners = manager.getAllocateWinnersInfo(limit);
            if (winners.isEmpty()) {
                System.out.println("Победителей нет (лимит = 0 или нет допущенных участников).");
                return;
            }

            System.out.println("Победители конкурса (в порядке рейтинга):");
            for (ScholarshipManager.WinnerInfo<ScholarshipApplication> w : winners) {
                System.out.printf("Студент ID: %d | Рейтинг: %.2f | Выбранная заявка ID: %d%n",
                        w.getStudentId(), w.getRating(), w.getWinningApplication().getId());
            }
        } catch (NumberFormatException e) {
            System.out.println("Ошибка ввода: лимит должен быть целым неотрицательным числом.");
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка конкурса: " + e.getMessage());
        }
    }

    private static void handleAnalytics(ScholarshipManager<ScholarshipApplication> manager) {
        System.out.println("\n--- Аналитика (Вариант 13) ---");
        System.out.println("Запрос: Map<Integer, Double> studentId -> средний балл всех заявок.");
        System.out.println("Включаются только студенты, подавшие не менее 2 заявок.");

        // Аналитический запрос выполняется ИСКЛЮЧИТЕЛЬНО через Stream API без циклов for/while
        Map<Integer, Double> result = manager.getAnalyticsStream()
                .collect(Collectors.groupingBy(
                        ScholarshipApplication::getStudentId,
                        Collectors.mapping(ScholarshipApplication::calculateScore, Collectors.toList())
                ))
                .entrySet().stream()
                .filter(entry -> entry.getValue().size() >= 2)
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        entry -> entry.getValue().stream().mapToDouble(Double::doubleValue).average().orElse(0.0)
                ));

        if (result.isEmpty()) {
            System.out.println("Нет студентов, удовлетворяющих условию (минимум 2 заявки).");
        } else {
            System.out.println("Результат (studentId -> средний балл):");
            result.forEach((studentId, avgScore) ->
                    System.out.printf("Студент #%d: средний балл = %.2f%n", studentId, avgScore));
        }
    }
}
