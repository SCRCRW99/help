package models;

public class MaintenanceRequest extends RepairRequest {
    private static final int MINUTES_PER_UNIT = 5;

    public MaintenanceRequest(int id, int customerId, int units, int priority) {
        super(id, customerId, units, priority);
    }

    @Override
    public int getRequiredMinutes() {
        return getUnits() * MINUTES_PER_UNIT;
    }

    @Override
    public int getRequiredParts() {
        return 0;
    }

    @Override
    public String getDetails() {
        return "Обслуживание: id=" + getId()
                + ", клиент=" + getCustomerId()
                + ", время=" + getRequiredMinutes() + " мин"
                + ", детали=" + getRequiredParts()
                + ", статус=" + (isCompleted() ? "выполнена" : "ожидает");
    }
}
