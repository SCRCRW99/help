package main;

import logic.RepairQueue;
import models.MaintenanceRequest;
import models.RepairRequest;
import models.ReplacementRequest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    private static final String[] NAMES_B = {
        "Короткий ремонт", "Экономия деталей", "Одна работа клиенту",
        "Резерв деталей", "Не более двух работ", "Учёт прежнего обслуживания"
    };

    // Задание 2, вариант Б2: priority по убыванию, детали по возрастанию,
    // время по возрастанию, затем id по возрастанию
    private static final Comparator<RepairRequest> ORDER_B2 = Comparator
            .comparingInt(RepairRequest::getPriority).reversed()
            .thenComparingInt(RepairRequest::getRequiredParts)
            .thenComparingInt(RepairRequest::getRequiredMinutes)
            .thenComparingInt(RepairRequest::getId);

    private static RepairQueue<RepairRequest> queue;
    private static int n;
    private static int stage = 0;      // номер последнего завершённого этапа
    private static int variantB;       // назначенный вариант задания 2
    private static int variantV;       // назначенный вариант задания 3

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        n = 0;
        while (n == 0) {
            System.out.print("Введите начальный номер N (1..36): ");
            if (!scanner.hasNextLine()) {
                return;
            }
            int value = parseInt(scanner.nextLine());
            if (value >= 1 && value <= 36) {
                n = value;
            } else {
                System.out.println("Ошибка: нужно ввести целое число от 1 до 36.");
            }
        }

        boolean running = true;
        while (running) {
            printMenu();
            if (!scanner.hasNextLine()) {
                break;
            }
            int choice = parseInt(scanner.nextLine());
            switch (choice) {
                case 1:
                    if (stage >= 1) {
                        System.out.println("Этап 1 уже выполнен.");
                    } else {
                        runStage1();
                    }
                    break;
                case 2:
                    if (stage >= 2) {
                        System.out.println("Этап 2 уже выполнен.");
                    } else if (stage < 1) {
                        System.out.println("Сначала выполните этап 1.");
                    } else {
                        runStage2();
                    }
                    break;
                case 3:
                    if (stage >= 3) {
                        System.out.println("Этап 3 уже выполнен.");
                    } else if (stage < 2) {
                        System.out.println("Сначала выполните этап 2.");
                    } else {
                        runStage3();
                    }
                    break;
                case 4:
                    showState();
                    break;
                case 5:
                    running = false;
                    System.out.println("Выход из программы.");
                    break;
                default:
                    System.out.println("Ошибка: выберите пункт меню от 1 до 5.");
            }
        }
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("=== Ремонтная мастерская ===");
        System.out.println("1. Выполнить задание 1 и вывести назначенный вариант задания 2");
        System.out.println("2. Выполнить задание 2 и вывести назначенный вариант задания 3");
        System.out.println("3. Выполнить задание 3 и вывести отчёт");
        System.out.println("4. Показать очередь, статусы и остатки времени и деталей");
        System.out.println("5. Выход из программы");
        System.out.print("Ваш выбор: ");
    }

    private static int parseInt(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    // Все исходные заявки, по возрастанию id
    private static List<RepairRequest> createSource() {
        List<RepairRequest> list = new ArrayList<>();
        list.add(new MaintenanceRequest(201, 21, 3, 5));
        list.add(new ReplacementRequest(202, 21, 2, 4, 5));
        list.add(new MaintenanceRequest(203, 22, 4, 5));
        list.add(new ReplacementRequest(204, 22, 1, 3, 5));
        list.add(new MaintenanceRequest(205, 23, 2, 2));
        list.add(new ReplacementRequest(206, 23, 3, 4, 0));
        list.add(new ReplacementRequest(207, 24, 1, 1, 0));
        list.add(new MaintenanceRequest(208, 24, 5, 4));
        list.add(new ReplacementRequest(209, 22, 1, 4, 0));
        list.add(new MaintenanceRequest(210, 25, 4, 2));
        return list;
    }

    private static List<Integer> idsOf(List<RepairRequest> list) {
        return list.stream().map(RepairRequest::getId).collect(Collectors.toList());
    }

    // Этап 1, вариант А2: units не меньше 2 и потребность во времени не более 30 минут
    private static void runStage1() {
        System.out.println("Вариант задания 1: А" + StageAccess.initial(n));

        queue = new RepairQueue<>(60, 2);
        Predicate<RepairRequest> selection =
                r -> r.getUnits() >= 2 && r.getRequiredMinutes() <= 30;
        createSource().stream().filter(selection).forEach(queue::add);

        List<Integer> ids = queue.getAnalyticsStream()
                .map(RepairRequest::getId)
                .sorted()
                .collect(Collectors.toList());
        int minutes = queue.getAnalyticsStream().mapToInt(RepairRequest::getRequiredMinutes).sum();
        int parts = queue.getAnalyticsStream().mapToInt(RepairRequest::getRequiredParts).sum();

        System.out.println("Добавлены заявки (ID): " + ids);
        System.out.println("Сумма потребностей: время = " + minutes + " мин, детали = " + parts);

        try {
            variantB = StageAccess.second(n, ids, minutes, parts);
        } catch (IllegalStateException e) {
            rejectByService(e);
            return;
        }
        stage = 1;
        System.out.println("Назначен вариант задания 2: Б" + variantB
                + " (" + NAMES_B[variantB - 1] + ")");
    }

    // Этап 2, вариант Б2: один process(), дополнительных ограничений нет
    private static void runStage2() {
        List<Integer> ids = idsOf(
                queue.process(r -> true, ORDER_B2, RepairRequest::markCompleted));

        System.out.println("Выполнены заявки (ID) в порядке выполнения: " + ids);
        System.out.println("Остаток: время = " + queue.getMinutes()
                + " мин, детали = " + queue.getParts());

        try {
            variantV = StageAccess.third(n, ids, queue.getMinutes(), queue.getParts());
        } catch (IllegalStateException e) {
            rejectByService(e);
            return;
        }
        stage = 2;
        System.out.println("Назначен вариант задания 3: В" + variantV);
    }

    // Этап 3, вариант В4: добавить 10 мин. и 1 дет., повторить обработку, отчёт Map<String, Long>
    private static void runStage3() {
        if (!queue.replenish(10, 1)) {
            System.out.println("Ошибка: ресурсы пополнить не удалось, данные не изменены.");
            return;
        }
        System.out.println("Ресурсы пополнены: +10 мин, +1 дет.");

        List<Integer> ids = idsOf(
                queue.process(r -> true, ORDER_B2, RepairRequest::markCompleted));

        System.out.println("Новые выполненные заявки (ID) в порядке выполнения: " + ids);
        System.out.println("Остаток: время = " + queue.getMinutes()
                + " мин, детали = " + queue.getParts());

        // Имя класса заявки -> число различных клиентов с выполненной заявкой этого типа
        Map<String, Long> report = Stream
                .<Class<? extends RepairRequest>>of(MaintenanceRequest.class, ReplacementRequest.class)
                .collect(Collectors.toMap(
                        Class::getSimpleName,
                        type -> queue.getAnalyticsStream()
                                .filter(r -> r.isCompleted() && type.isInstance(r))
                                .map(RepairRequest::getCustomerId)
                                .distinct()
                                .count()));

        System.out.println("Отчёт В4 (тип заявки -> число клиентов с выполненной заявкой):");
        report.forEach((type, count) -> System.out.println("  " + type + " -> " + count));
        stage = 3;
    }

    private static void showState() {
        if (queue == null) {
            System.out.println("Очередь ещё не сформирована. Выполните этап 1.");
            return;
        }
        System.out.println("Очередь:");
        queue.getAnalyticsStream().forEach(r -> System.out.println("  " + r.getDetails()));
        System.out.println("Остаток времени: " + queue.getMinutes()
                + " мин, деталей: " + queue.getParts());
    }

    private static void rejectByService(IllegalStateException e) {
        System.out.println("Служебный код отклонил результат: " + e.getMessage());
        System.out.println("Проверьте решение. Цепочка сброшена, начните с пункта 1.");
        queue = null;
        stage = 0;
        variantB = 0;
        variantV = 0;
    }
}

final class StageAccess {
    private static final int[] S = {0, 3, 3, 2, 0, 1};
    private static final int[] A = {
        0x2e02a10d, 0x658e283b, 0x4bdc593a, 0xc22e0b9e, 0xbf0fca1e,
        0xa0951f33
    };
    private static final int[] B = {
        0x29657c36, 0x96d25ad4, 0xa1c42961, 0xa1c42961, 0x49f39b4a,
        0x49f39b4a, 0x49f39b4a, 0x1f4445f7, 0x3fb6878e, 0x3fb6878e,
        0x49f39b4a, 0x49f39b4a, 0x574556c0, 0xa1c42961, 0xa1c42961,
        0x49f39b4a, 0x49f39b4a, 0xa37914c6, 0xa1c42961, 0x49f39b4a,
        0x49f39b4a, 0x29657c36, 0xe3f8f103, 0xa1c42961, 0x49f39b4a,
        0x49f39b4a, 0xf3b1ab4a, 0x3fb6878e, 0x3fb6878e, 0x49f39b4a,
        0x83f6e3cb, 0x574556c0, 0x892997a2, 0x892997a2, 0x892997a2,
        0x83f6e3cb
    };
    static int initial(int n) {
        if (n < 1 || n > 36)
            throw new IllegalArgumentException("N: 1..36");
        return (n - 1) / 6 + 1;
    }
    static int second(int n, java.util.List<Integer> ids,
                      int minutes, int parts) {
        return check(n, ids, minutes, parts, A[initial(n) - 1], 0);
    }
    static int third(int n, java.util.List<Integer> ids,
                     int minutes, int parts) {
        int a = initial(n);
        int b = 1 + Math.floorMod((long) A[a - 1] + (n - 1) % 6, 6);
        return check(n, ids, minutes, parts, B[n - 1], b);
    }
    private static int check(int n, java.util.List<Integer> ids,
            int minutes, int parts, int expected, int previous) {
        if (ids == null) throw new IllegalArgumentException("ids: null");
        int actual = (ids + "|" + minutes + "|" + parts).hashCode();
        if (actual != expected)
            throw new IllegalStateException("Check stage result");
        int p = (n - 1) % 6;
        long key = previous == 0 ? (long) actual + p
            : (actual >>> 5) + 1L * p + 0L * previous + S[initial(n) - 1];
        return 1 + Math.floorMod(key, 6);
    }
}
