package logic;

import models.RepairRequest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class RepairQueue<T extends RepairRequest> {
    private static final int MAX_MINUTES = 1440;
    private static final int MAX_PARTS = 1000;

    private final List<T> requests = new ArrayList<>();
    private int minutes;
    private int parts;

    public RepairQueue(int minutes, int parts) {
        if (minutes < 0 || minutes > MAX_MINUTES) {
            throw new IllegalArgumentException("minutes должен быть от 0 до " + MAX_MINUTES);
        }
        if (parts < 0 || parts > MAX_PARTS) {
            throw new IllegalArgumentException("parts должен быть от 0 до " + MAX_PARTS);
        }
        this.minutes = minutes;
        this.parts = parts;
    }

    public boolean add(T request) {
        if (request == null || request.isCompleted()) {
            return false;
        }
        for (T existing : requests) {
            if (existing.getId() == request.getId()) {
                return false;
            }
        }
        requests.add(request);
        return true;
    }

    public int getMinutes() {
        return minutes;
    }

    public int getParts() {
        return parts;
    }

    public boolean replenish(int addMinutes, int addParts) {
        if (addMinutes < 0 || addParts < 0 || (addMinutes == 0 && addParts == 0)) {
            return false;
        }
        if (minutes + addMinutes > MAX_MINUTES || parts + addParts > MAX_PARTS) {
            return false;
        }
        minutes += addMinutes;
        parts += addParts;
        return true;
    }

    public Stream<T> getAnalyticsStream() {
        return new ArrayList<>(requests).stream();
    }

    public List<T> process(Predicate<T> condition, Comparator<T> order, Consumer<T> action) {
        if (condition == null || order == null || action == null) {
            throw new IllegalArgumentException("condition, order и action не должны быть null");
        }
        List<T> waiting = new ArrayList<>();
        for (T request : requests) {
            if (!request.isCompleted()) {
                waiting.add(request);
            }
        }
        waiting.sort(order);

        List<T> done = new ArrayList<>();
        for (T request : waiting) {
            int needMinutes = request.getRequiredMinutes();
            int needParts = request.getRequiredParts();
            if (needMinutes <= minutes && needParts <= parts && condition.test(request)) {
                minutes -= needMinutes;
                parts -= needParts;
                action.accept(request);
                done.add(request);
            }
        }
        return done;
    }
}
