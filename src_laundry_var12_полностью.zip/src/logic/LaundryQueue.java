package logic;

import models.LaundryRequest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class LaundryQueue<T extends LaundryRequest> {
    private final List<T> requests = new ArrayList<>();
    private int capacity;

    public LaundryQueue(int capacity) {
        if (capacity < 1 || capacity > 20) {
            throw new IllegalArgumentException("Вместимость должна быть от 1 до 20.");
        }
        this.capacity = capacity;
    }

    public boolean add(T request) {
        if (request == null || request.isWashed()) {
            return false;
        }
        for (T existing : requests) {
            if (existing.getId() == request.getId()) {
                return false;
            }
        }
        requests.add(request);
        return true;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean setCapacity(int capacity) {
        if (capacity < 1 || capacity > 20) {
            return false;
        }
        this.capacity = capacity;
        return true;
    }

    public Stream<T> getAnalyticsStream() {
        return requests.stream();
    }

    public List<T> washBatch(Predicate<T> condition, Comparator<T> order, Consumer<T> action) {
        // Рассматриваем ожидающие заявки в порядке order
        List<T> pending = requests.stream()
                .filter(r -> !r.isWashed())
                .sorted(order)
                .collect(Collectors.toList());

        List<T> accepted = new ArrayList<>();
        int currentLoad = 0;
        int batchMode = 0; // 0 означает, что режим еще не выбран

        for (T req : pending) {
            int needed = req.getLoadUnits();
            // Хватает ли места?
            if (currentLoad + needed <= capacity) {
                // Совместим ли режим?
                if (batchMode == 0 || req.getMode() == batchMode) {
                    if (condition.test(req)) {
                        if (batchMode == 0) {
                            batchMode = req.getMode();
                        }
                        currentLoad += needed;
                        action.accept(req);
                        accepted.add(req);
                    }
                }
            }
        }

        return accepted;
    }
}
