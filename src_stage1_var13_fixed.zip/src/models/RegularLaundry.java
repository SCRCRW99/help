package models;

public class RegularLaundry extends LaundryRequest {
    public RegularLaundry(int id, int customerId, int weightUnits, int mode, int priority) {
        super(id, customerId, weightUnits, mode, priority);
    }

    @Override
    public int getLoadUnits() {
        return getWeightUnits();
    }

    @Override
    public String getDetails() {
        return String.format("Обычные вещи #%d [Клиент %d]: вес=%d, режим=%d, приор=%d, загрузка=%d, статус=%s",
                getId(), getCustomerId(), getWeightUnits(), getMode(), getPriority(),
                getLoadUnits(), isWashed() ? "ВЫСТИРАНО" : "ОЖИДАЕТ");
    }
}
